<?php
if(isset($_POST['submit']))
{
$fullname = $_POST['fullname'];
$phonenumber = $_POST['phonenumber'];
$Email = $_POST['Email'];
$id= $_POST['id'];
$location=$_POST['location'];
$conn =mysqli_connect("localhost","root","","car_rental");

$sql = "INSERT INTO bentley VALUES ('$fullname','$phonenumber', '$Email', '$id','$location')";
	if (mysqli_query($conn,$sql)) 
	{
    		//echo "New record created successfully";
		header("Location: http://localhost/car_rental/pay.php");
		
	} 
	else 
	{
    		echo "Error: " . $sql . "<br>" . mysqli_error($conn);
	}
}?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Simple Theme</title>
<link href="css/multiColumnTemplate.css" rel="stylesheet" type="text/css">
<!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
<!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
<!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
<script type="text/javascript">
function MM_swapImgRestore() { //v3.0
  var i,x,a=document.MM_sr; for(i=0;a&&i<a.length&&(x=a[i])&&x.oSrc;i++) x.src=x.oSrc;
}
function MM_preloadImages() { //v3.0
  var d=document; if(d.images){ if(!d.MM_p) d.MM_p=new Array();
    var i,j=d.MM_p.length,a=MM_preloadImages.arguments; for(i=0; i<a.length; i++)
    if (a[i].indexOf("#")!=0){ d.MM_p[j]=new Image; d.MM_p[j++].src=a[i];}}
}

function MM_findObj(n, d) { //v4.01
  var p,i,x;  if(!d) d=document; if((p=n.indexOf("?"))>0&&parent.frames.length) {
    d=parent.frames[n.substring(p+1)].document; n=n.substring(0,p);}
  if(!(x=d[n])&&d.all) x=d.all[n]; for (i=0;!x&&i<d.forms.length;i++) x=d.forms[i][n];
  for(i=0;!x&&d.layers&&i<d.layers.length;i++) x=MM_findObj(n,d.layers[i].document);
  if(!x && d.getElementById) x=d.getElementById(n); return x;
}

function MM_swapImage() { //v3.0
  var i,j=0,x,a=MM_swapImage.arguments; document.MM_sr=new Array; for(i=0;i<(a.length-2);i+=3)
   if ((x=MM_findObj(a[i]))!=null){document.MM_sr[j++]=x; if(!x.oSrc) x.oSrc=x.src; x.src=a[i+2];}
}
</script>
</head>
<body onLoad="MM_preloadImages('images/b2.jpg')">
<div class="container">
  <header>
    <div class="primary_header">
      <h1 class="title">CAR RENTAL SYSTEM</h1>
    </div>
    <nav class="secondary_header" id="menu">
      <ul>
        <li><a href="home.php"> Home</a></li>
        <li>Rent Cars</li>
		  <li><a href="contact.php">Contact</a></li>
		  <li><a href="login.php">Client Login</a>  </li>
		  <li> <a href="admin.php">Admin login</a></li>
      </ul>
    </nav>
  </header>
  <section>
    <h2 class="noDisplay">Main Content</h2>
    <article class="left_article">
      <h3>Bentley Continental GT</h3>
      <p>with a completely new 6.0 litre, twin turbocharged W12 engine, a step-change in technology and a truly stunning design language, the new Continental GT is unmatched in its class.</p>
      <p><strong>Fill the details for Hiring</strong></p>
      
		<form id="form1" name="form1" method="post">
<table width="493" height="202" border="0">
        <tbody>
          <tr>
            <th scope="row"><table width="487" height="202" border="0">
              <tbody>
                <tr>
                  <th width="204" scope="row">Full Name :</th>
                  <td width="273"><input type="text" name="fullname" id="fullname"></td>
                </tr>
                <tr>
                  <th scope="row">Phone Number :</th>
                  <td><input type="number" name="phonenumber" id="phonenumber"></td>
                </tr>
                <tr>
                  <th scope="row">Email ID :</th>
                  <td><input type="email" name="Email" id="Email"></td>
                </tr>
                <tr>
                  <th scope="row">ID Proof :</th>
                  <td><input type="text" name="id" id="id"></td>
                </tr>
                
                <tr>
                  <th scope="row">Location :</th>
                  <td><input type="text" name="location" id="location"></td>
                </tr>
                <tr>
                  <th colspan="2" scope="row">&nbsp;</th>
                  </tr>
              </tbody>
            </table></th>
          </tr>
        </tbody>
	  </table>
			
      <form action="pay.php" method="post">
	    <center><input type="submit" name="submit" id="submit" value="Submit"></center>
	  </form></p><p>&nbsp;</p>
    </article>
    <aside class="right_article">
      <p>&nbsp;</p>
      <p>&nbsp;</p>
      <p><a href="#" onMouseOut="MM_swapImgRestore()" onMouseOver="MM_swapImage('bently','','images/b2.jpg',1)"><img src="images/1.jpg" alt="" width="450" height="300" id="bently"></a></p>
    </aside>
  </section>
  
  <div class="social">
    <p class="social_icon"><img src="images/s1.png" width="100" height="100" alt=""/></p>
    <p class="social_icon"><img src="images/s2.png" width="100" height="100" alt=""/></p>
    <p class="social_icon"><img src="images/s3.png" width="100" height="100" alt=""/></p>
    <p class="social_icon"><img src="images/s4.png" width="100" height="100" alt=""/></p>
  </div>
  <footer class="secondary_header footer">
    <div class="copyright">
      <div class="copyright">&copy;2020 - <strong>Car Rental System</strong></div>
    </div>
  </footer>
</div>
</body>
</html>
