<!doctype html>
<html>
<head>

<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Home</title>
<link href="css/multiColumnTemplate.css" rel="stylesheet" type="text/css">
<!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
<!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
<!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
</head>
<body>
<div class="container">
  <header>
    <div class="primary_header">
      <h1 class="title"> CAR RENTAL SYSTEM</h1>
    </div>
    <nav class="secondary_header" id="menu">
      <ul>
		  <li> <a href="home.php">Home</a></li>
        <li>Rent Cars</li>
		  <li><a href="contact.php">Contact</a></li>
		  <li><a href="login.php">Client Login </a></li>
		  <li> <a href="admin.php">Admin login</a></li>
      </ul>
    </nav>
  </header>
  <section>
    <h2 class="noDisplay">Main Content</h2>
    
    
  </section>
  <div class="row">
    <div class="columns">
      <p class="thumbnail_align"><center><img src="images/1.jpg" width="160" height="100" alt=""/> </center></p>
      <h4>Bentley Continental GT</h4>
      <p>with a completely new 6.0 litre, twin turbocharged W12 engine, a step-change in technology and a truly stunning design language, the new Continental GT is unmatched in its class.</p>
      <p>
		  <center>
      <form action="bentley.php" method="post">
       <input type="submit" value="Book Now">
			  </form>
	    </center>
      </p>
    </div>
    <div class="columns">
      <p class="thumbnail_align"> <center><img src="images/2.jpg" width="160" height="100" alt=""/></center></p>
      <h4>Rolls Royce Cullinan</h4>
      <p>This is freedom absolute. The first all-terrain SUV from Rolls-Royce makes luxury off-road travel a reality for the first time. Cullinan accommodates every traveller in unparalleled comfort. </p>
      <p>
		  <center>
	 <form action="rolls.php" method="post">
      <input type="submit" value="Book Now">
			  </form>
	    </center>
      </p>
		 
    </div>
    <div class="columns">
      <p class="thumbnail_align"> <center><img src="images/3.jpg" width="160" height="100" alt=""/></center></p>
      <h4>Tesla CyberTruck</h4>
      <p>The Tesla Cybertruck is an all - electric,battery powered,light commercial vehicle in development by Tesla, Inc. Three models have been announced, with range estimates  250–500 miles.</p>
      <p>
		  <center>
			  <form action="tesla.php" method="post">
        <input type="submit"  value="Book Now">
			  </form>
	    </center>
      </p>
    </div>
    <div class="columns">
      <p class="thumbnail_align"> <center><img src="images/4.jpg" width="160" height="100" alt=""/></center> </p>  
      <h4>Range Rover Velar</h4>
      <p>The Range Rover Velar design philosophy is revolutionary. Striking proportions, flush door handles and an integrated rear spoiler all improve aerodynamics. Velar has capability at its core. </p>
      <p>
		  <center>
			  <form action="range.php" method="post">
        <input type="submit"  value="Book Now">
			  </form>
	    </center>
      </p>
    </div>
    <div class="columns">
      <p class="thumbnail_align"><center><img src="images/5.jpg" width="160" height="100" alt=""/></center></p>
      <h4>Mahindra XUV500</h4>
      <p>The Mahindra XUV500 (pronounced as XUV five double O) is a compact Sport utility vehicle produced by the Indian automobile company Mahindra &amp; Mahindra. </p>
      <p>
		  <form action="xuv.php" method="post">
        <center><input type="submit" value="Book Now"></center>
		</form>
      </p>
    </div>
    <div class="columns">
      <p class="thumbnail_align"> <center><img src="images/6.jpg" width="160" height="100" alt=""/></center></p>
      <h4>Jeep Compass</h4>
      <p>When you blend athletic styling with sweeping curves to create a sleek yet sharp look, you get a Jeep® Compass that leaves a trail of amazement wherever it goes. Explore now and decide </p>
      <p>
		  <form action="jeep.php" method="post">
        <center><input type="submit" value="Book Now"></center>
		</form>
      </p>
    </div>
    <div class="columns">
      <p class="thumbnail_align"> <center><img src="images/7.png" width="160" height="100" alt=""/></center></p>
      <h4>Skoda Kodiaq</h4>
      <p>The ŠKODA KODIAQ can dress to impress, but is just as at ease in seeing to your family&rsquo;s everyday needs. Enjoy the confidence and economy of the ŠKODA KODIAQ, </p>
      <p>
		  <form action="skoda.php" method="post">
       <center> <input type="submit" value="Book Now"></center>
		</form>
      </p>
    </div>
    <div class="columns">
      <p class="thumbnail_align"> <center><img src="images/8.jpg" width="160" height="100" alt=""/></center></p>
      <h4>MG Hector</h4>
      <p>PERSONALIZE YOUR OWN MG HECTOR TO GET A FEEL OF YOUR DREAM CAR. EQUIPPED WITH SAFETY FEATURES THAT REPLICATE THE HUMAN NATURE </p>
      <p>
		  <form action="hector.php" method="post">
       <center><input type="submit" value="Book Now"></center> 
		</form>
      </p>
    </div>
  </div>
 
  </div>
  <div class="social">
    <p class="social_icon"><img src="images/s1.png" width="100" height="100" alt=""/></p>
    <p class="social_icon"><img src="images/s2.png" width="100" height="100" alt=""/></p>
    <p class="social_icon"><img src="images/s3.png" width="100" height="100" alt=""/></p>
    <p class="social_icon"><img src="images/s4.png" width="100" height="100" alt=""/></p>
  </div>
  <footer class="secondary_header footer">
    <div class="copyright">&copy;2020 - <strong>Car Rental System</strong></div>
  </footer>
</div>
</body>
</html>
