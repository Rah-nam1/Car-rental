<?php session_start(); 
if(isset($_POST['submit'])){
$logins = array('abc' => '123456','username1' => 'password1','username2' => 'password2');

$Username = isset($_POST['username']) ? $_POST['username'] : '';
$Password = isset($_POST['password']) ? $_POST['password'] : '';

if (isset($logins[$Username]) && $logins[$Username] == $Password){
$_SESSION['UserData']['Username']=$logins[$Username];
header("location:index.php");
exit;
} else {
$msg="<span style='color:red'>Invalid Login Details</span>";
}
}
?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Client Login</title>
<link href="css/multiColumnTemplate.css" rel="stylesheet" type="text/css">
<!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
<!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
<!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
</head>
<body>
<div class="container">
<!--
<header>
    <div class="primary_header">
      <h1 class="title">CAR RENTAL SYSTEM</h1>
    </div>
    <nav class="secondary_header" id="menu">
       <ul>
        <li><a href="home.php"> Home</a></li>
        <li>Rent Cars</li>
		  <li><a href="contact.php">Contact</a></li>
		   <li><a href="login.php">Client Login </a> </li>
		   <li> <a href="admin.php">Admin login</a></li>
      </ul>
    </nav>
  </header>
-->
  <section>
    <h2 class="noDisplay">Main Content</h2>
    <article class="left_article">
      <h3>Client LOgin</h3>
      <p>&nbsp;</p>
		<form method="post" >
      <table width="200" border="0">
        <tbody>
          <tr>
            <td>&nbsp;<strong><h4>Username:</h4><br>
            </strong>
              <input type="text" name="user_email" id="user_email">
              <br>
            <br></td>
          </tr>
          <tr>
            <td><label for="password"><strong><h4>Password:</h4></strong></label>
            <input type="password" name="user_pass" id="user_pass">
            <br><br>
				<center>
            <input type="submit" name="submit" id="submit" value="Submit"></center></td>
            <tr></tr>
          </tr>
			</form>
        </tbody>
      </table>
<label for="textfield"><br>
      </label>
<p>&nbsp;</p>
    </article>
    <table width="200" border="0">
      <tbody>
<tr>
        <td>&nbsp;</td>
        </tr>
      </tbody>
    </table>
    <aside class="right_article">
      <input type="image" name="imageField" id="imageField" src="images/self.jpg" width="650" height="400" >
    </aside>
  </section>
  <div class="row">
   
  <div class="social">
    <p class="social_icon"><img src="images/s1.png"  width="100" height="100" alt=""/></p>
    <p class="social_icon"><img src="images/s2.png"  width="100" height="100" alt=""/></p>
    <p class="social_icon"><img src="images/s3.png"  width="100" height="100" alt=""/></p>
    <p class="social_icon"><img src="images/s4.png"  width="100" height="100" alt=""/></p>
  </div>
  <footer class="secondary_header footer"> 
    <div class="copyright">&copy;2020 - <strong>Car Rental System</strong></div>
  </footer>
</div>
</body>
</html>
